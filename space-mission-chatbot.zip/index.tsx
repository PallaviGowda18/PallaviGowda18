import React, { useState, useEffect, useRef } from 'https://esm.sh/react@18.2.0';
import ReactDOM from 'https://esm.sh/react-dom@18.2.0/client';
import { GoogleGenAI, Chat } from 'https://esm.sh/@google/genai';

declare global {
    namespace JSX {
        interface IntrinsicElements {
            [elemName: string]: any;
        }
    }
    const marked: {
      parse(markdown: string): string;
    };
}

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}
const ai = new GoogleGenAI({ apiKey: API_KEY });

interface Message {
    role: 'user' | 'model';
    content: string;
}

const content = {
  kn: {
    landingTitle: 'ಕನ್ನಡ ರಾಜ್ಯೋತ್ಸವ',
    enterButton: 'ಪ್ರವೇಶಿಸಿ',
    landingTopics: [
      'ಅಂತರಿಕ್ಷ ಮಿಷನ್ಗಳು',
      'ಚಂದ್ರಯಾನ',
      'ಮಂಗಳಯಾನ',
      'ಗಗನಯಾನ',
      'ಕರ್ನಾಟಕ ಸಾಧನೆಗಳು',
      'ಭವಿಷ್ಯದ ಮಿಷನ್ಗಳು'
    ],
    mainTitle: 'ಕನ್ನಡ ರಾಜ್ಯೋತ್ಸವ',
    chatTopics: [
      { id: 'chandrayaan', name: 'ಚಂದ್ರಯಾನ', icon: 'moon' },
      { id: 'mangalyaan', name: 'ಮಂಗಳಯಾನ', icon: 'planet' },
      { id: 'gaganyaan', name: 'ಗಗನಯಾನ', icon: 'rocket' },
      { id: 'isro', name: 'ಕರ್ನಾಟಕದಲ್ಲಿ ಇಸ್ರೋ', icon: 'isro' },
    ],
    welcomeMessage: `<h2>ನಮಸ್ಕಾರ! ಕನ್ನಡ ರಾಜ್ಯೋತ್ಸವದ ಬಾಹ್ಯಾಕಾಶ ಸಂಭ್ರಮಕ್ಕೆ ಸುಸ್ವಾಗತ!</h2><p>ಭಾರತದ ಬಾಹ್ಯಾಕಾಶ ಯಾನದಲ್ಲಿ ಕರ್ನಾಟಕದ ಅದ್ಭುತ ಕೊಡುಗೆಗೆ ಇದು ಒಂದು ಗೌರವ. ಪ್ರಾರಂಭಿಸಲು ಮೇಲಿನ ವಿಷಯವನ್ನು ಆಯ್ಕೆಮಾಡಿ ಅಥವಾ ಪ್ರಶ್ನೆ ಕೇಳಿ!</p>`,
    inputPlaceholder: 'ಮುಂದಿನ ಪ್ರಶ್ನೆ ಕೇಳಿ...',
    sendButton: 'ಕಳುಹಿಸಿ',
    systemInstruction: "You are a friendly and enthusiastic guide celebrating Kannada Rajyotsava, speaking in KANNADA. Explain topics in relation to India's space missions and Karnataka's role. Use simple Kannada language and markdown format. Include a title and bullet points where appropriate.",
    chatError: "ಚಾಟ್ ಸೆಷನ್ ಪ್ರಾರಂಭಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಪುಟವನ್ನು ರಿಫ್ರೆಶ್ ಮಾಡಿ.",
    sendError: "ಕ್ಷಮಿಸಿ, ಏನೋ ತಪ್ಪಾಗಿದೆ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.",
  },
  en: {
    landingTitle: 'Kannada Rajyotsava',
    enterButton: 'Enter',
    landingTopics: [
      'Space Missions',
      'Chandrayaan',
      'Mangalyaan',
      'Gaganyaan',
      'Karnataka\'s Achievements',
      'Future Missions'
    ],
    mainTitle: 'Kannada Rajyotsava',
    chatTopics: [
      { id: 'chandrayaan', name: 'Chandrayaan', icon: 'moon' },
      { id: 'mangalyaan', name: 'Mangalyaan', icon: 'planet' },
      { id: 'gaganyaan', name: 'Gaganyaan', icon: 'rocket' },
      { id: 'isro', name: 'ISRO in Karnataka', icon: 'isro' },
    ],
    welcomeMessage: `<h2>Greetings! Welcome to the Kannada Rajyotsava Space Celebration!</h2><p>This is a tribute to Karnataka's immense contribution to India's journey among the stars. Select a topic above or ask me a question to begin!</p>`,
    inputPlaceholder: 'Ask a follow-up question...',
    sendButton: 'Send',
    systemInstruction: "You are a friendly and enthusiastic guide celebrating Kannada Rajyotsava, speaking in ENGLISH. Explain topics in relation to India's space missions and Karnataka's role. Use simple language and markdown format. Include a title and bullet points where appropriate.",
    chatError: "Could not start a chat session. Please refresh the page.",
    sendError: "Sorry, something went wrong. Please try again.",
  }
};

const TopicIcons: { [key: string]: React.ReactNode } = {
    moon: (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <defs>
                <radialGradient id="moonGrad">
                    <stop offset="0%" stopColor="#E0E0E0"/>
                    <stop offset="100%" stopColor="#BDBDBD"/>
                </radialGradient>
            </defs>
            <circle cx="12" cy="12" r="10" fill="url(#moonGrad)"/>
            <circle cx="7" cy="9" r="1.5" fill="#9E9E9E"/>
            <circle cx="15" cy="14" r="2" fill="#9E9E9E"/>
            <circle cx="14" cy="7" r="1" fill="#9E9E9E"/>
        </svg>
    ),
    planet: (
        <svg viewBox="0 0 24 24">
            <defs>
                <radialGradient id="marsGrad">
                    <stop offset="20%" stopColor="#E57373"/>
                    <stop offset="100%" stopColor="#C62828"/>
                </radialGradient>
            </defs>
            <circle cx="12" cy="12" r="8" fill="url(#marsGrad)"/>
            <g transform="rotate(-20 12 12)">
                <ellipse cx="12" cy="12" rx="11" ry="4" stroke="#B0BEC5" strokeWidth="0.75" fill="none" opacity="0.8"/>
                <path d="M 2.8 10.5 L 4.5 9.5" stroke="#B0BEC5" strokeWidth="1.5" />
            </g>
        </svg>
    ),
    rocket: (
        <svg viewBox="0 0 24 24">
            <g transform="translate(0 -1)">
                <path d="M12 2 L15 10 L15 18 L9 18 L9 10 Z" fill="#E0E0E0" stroke="#9E9E9E" strokeWidth="0.5"/>
                <path d="M12 2 L15 10 L9 10 Z" fill="#FFFFFF"/>
                <path d="M9 12 L7 14 L7 19 L9 18 Z" fill="#BDBDBD"/>
                <path d="M15 12 L17 14 L17 19 L15 18 Z" fill="#BDBDBD"/>
                <path d="M9 18 L15 18 L12 23 Z" fill="orange"/>
            </g>
        </svg>
    ),
    isro: (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <defs>
                <linearGradient id="isroGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="var(--kannada-yellow)" />
                    <stop offset="100%" stopColor="var(--kannada-red)" />
                </linearGradient>
            </defs>
            <path fill="url(#isroGrad)" d="M12 2 L2 7 L12 12 L22 7 Z M2 17 L12 22 L22 17 L12 12 Z M2 12 L12 17 L22 12 L12 7 Z"/>
        </svg>
    ),
};

const KarnatakaMap = () => (
    <svg className="glowing-map-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" overflow="visible">
      <defs>
        <linearGradient id="karnatakaGradient" x1="0%" y1="50%" x2="100%" y2="50%">
            <stop offset="0%" stopColor="var(--kannada-yellow)" />
            <stop offset="100%" stopColor="var(--kannada-red)" />
        </linearGradient>
        <clipPath id="mapClip">
            <path d="M178.6,65.8l-19,2.7l-15.6,18.4l-11,10.6l-13.3,1.9l-11,4.4l-10.3,1.8L93,109.9l-10.3,9.7l-9.1,2.8l-9.7,7l-3.2,11.3l-5,6.3l2.8,11l-3.8,11.9l-4.7,6l2.2,9.7l-1.6,11l-3.8,12.5l-2.2,2.8l-0.6,11l1.6,4.7l4.4,1.6l4.4,5.3l5.6,14.2l-2.2,6.3l-2.5,7.3l-6,11.3l-1.9,8.5l2.2,5.3l1.9,1.9l5,5.6l8.8,1.6l6.6-0.3l10.3,5.6l9.4-1.9l4.7,2.5l6.3-1.6l8.2,3.5l1.9-2.2l3.2-6.3l6-3.2l5-5.3l11-1.3l8.5,1.6l10-4.1l8.5,1.9l4.7-4.1l2.5,1.9l3.8-0.9l5,2.5l2.2,2.8l4.4,0.3l10-5.3l3.5-2.2l6.3-5.3l11,0.6l14.2-1.9l12.9,3.5l8.5,8.2l-0.3,12.9l-4.1,8.5l-0.3,10.7l-4.4,6.3l0.9,13.2l5.6,12.5l-0.3,10.3l2.5,4.7l6.6,1.9l4.4-4.1l7.6,1.9l8.8-1.9l8.2-7l3.8-9.1l-0.6-11.6l-4.7-9.4l0.3-10.7l-2.8-11.9l-7.3-10.3l-2.2-13.5l-6-13.5l-9.1-8.5l-12.9-4.7l-12.2-8.5l-8.5-12.2l-4.7-14.5l-8.5-10.7l-11-5l-13.8-0.3l-12.5-4.4l-14.2-11l-10.3-12.5l-5.3-11.9l-1.3-11l3.5-11.9l-1.9-10.3l-6-7.3l-11.3-5.3l-11.9,1.3l-9.1-4.7L178.6,65.8z"/>
        </clipPath>
      </defs>
      <path fill="url(#karnatakaGradient)" d="M178.6,65.8l-19,2.7l-15.6,18.4l-11,10.6l-13.3,1.9l-11,4.4l-10.3,1.8L93,109.9l-10.3,9.7l-9.1,2.8l-9.7,7l-3.2,11.3l-5,6.3l2.8,11l-3.8,11.9l-4.7,6l2.2,9.7l-1.6,11l-3.8,12.5l-2.2,2.8l-0.6,11l1.6,4.7l4.4,1.6l4.4,5.3l5.6,14.2l-2.2,6.3l-2.5,7.3l-6,11.3l-1.9,8.5l2.2,5.3l1.9,1.9l5,5.6l8.8,1.6l6.6-0.3l10.3,5.6l9.4-1.9l4.7,2.5l6.3-1.6l8.2,3.5l1.9-2.2l3.2-6.3l6-3.2l5-5.3l11-1.3l8.5,1.6l10-4.1l8.5,1.9l4.7-4.1l2.5,1.9l3.8-0.9l5,2.5l2.2,2.8l4.4,0.3l10-5.3l3.5-2.2l6.3-5.3l11,0.6l14.2-1.9l12.9,3.5l8.5,8.2l-0.3,12.9l-4.1,8.5l-0.3,10.7l-4.4,6.3l0.9,13.2l5.6,12.5l-0.3,10.3l2.5,4.7l6.6,1.9l4.4-4.1l7.6,1.9l8.8-1.9l8.2-7l3.8-9.1l-0.6-11.6l-4.7-9.4l0.3-10.7l-2.8-11.9l-7.3-10.3l-2.2-13.5l-6-13.5l-9.1-8.5l-12.9-4.7l-12.2-8.5l-8.5-12.2l-4.7-14.5l-8.5-10.7l-11-5l-13.8-0.3l-12.5-4.4l-14.2-11l-10.3-12.5l-5.3-11.9l-1.3-11l3.5-11.9l-1.9-10.3l-6-7.3l-11.3-5.3l-11.9,1.3l-9.1-4.7L178.6,65.8z"/>
      <g clipPath="url(#mapClip)">
            {/* Rocket 1 */}
            <g className="rocket" style={{ animationDelay: '0s' }}>
                <path d="M 200 380 L 210 380 L 210 350 L 205 340 L 200 350 Z" fill="#E0E0E0" stroke="#9E9E9E" strokeWidth="1"/>
                <polygon className="rocket-fire" points="200,380 210,380 205,400" fill="orange" />
            </g>
            {/* Rocket 2 */}
            <g className="rocket" style={{ animationDelay: '1.5s' }}>
                <path d="M 300 350 L 310 350 L 310 320 L 305 310 L 300 320 Z" fill="#E0E0E0" stroke="#9E9E9E" strokeWidth="1"/>
                <polygon className="rocket-fire" points="300,350 310,350 305,370" fill="orange" />
            </g>
       </g>
    </svg>
);

const ChatbotCharacter = () => (
    <svg className="chatbot-character" viewBox="0 0 100 100">
        <defs>
            <radialGradient id="grad1" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                <stop offset="0%" style={{stopColor: 'var(--hologram-blue)', stopOpacity:1}} />
                <stop offset="100%" style={{stopColor: 'var(--space-dark)', stopOpacity:0.8}} />
            </radialGradient>
            <filter id="glow">
                <feGaussianBlur stdDeviation="2.5" result="coloredBlur" />
                <feMerge>
                    <feMergeNode in="coloredBlur" />
                    <feMergeNode in="SourceGraphic" />
                </feMerge>
            </filter>
        </defs>
        <g filter="url(#glow)">
            {/* Body */}
            <rect x="25" y="45" width="50" height="40" rx="10" fill="url(#grad1)" stroke="var(--hologram-blue)" strokeWidth="1"/>
            {/* Head */}
            <circle cx="50" cy="30" r="20" fill="url(#grad1)" stroke="var(--hologram-blue)" strokeWidth="1"/>
            {/* Eye */}
            <circle cx="50" cy="30" r="5" fill="var(--text-light)"/>
            {/* Antenna */}
            <line x1="65" y1="15" x2="70" y2="10" stroke="var(--hologram-blue)" strokeWidth="2"/>
            <circle cx="71" cy="9" r="2" fill="var(--hologram-blue)"/>
        </g>
    </svg>
);

const KarnatakaFlag = () => (
    <svg className="karnataka-flag" viewBox="0 0 100 60" preserveAspectRatio="none">
        <rect width="100" height="30" fill="var(--kannada-yellow)" />
        <rect y="30" width="100" height="30" fill="var(--kannada-red)" />
    </svg>
);

const App = () => {
    const [appState, setAppState] = useState<'landing' | 'chatbot'>('landing');
    const [language, setLanguage] = useState<'kn' | 'en'>('kn');
    const [isLoading, setIsLoading] = useState(true);
    const [activeTopic, setActiveTopic] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [chatSession, setChatSession] = useState<Chat | null>(null);
    const [messages, setMessages] = useState<Message[]>([]);
    const [userInput, setUserInput] = useState('');
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const initChat = async () => {
            setIsLoading(true);
            setError(null);
            try {
                const session = ai.chats.create({
                    model: 'gemini-2.5-flash',
                    config: {
                        systemInstruction: content[language].systemInstruction,
                    }
                });
                setChatSession(session);
                setMessages([{ role: 'model', content: content[language].welcomeMessage }]);
            } catch (err) {
                console.error("Failed to initialize chat session:", err);
                setError(content[language].chatError);
            } finally {
                setIsLoading(false);
            }
        };
        initChat();
    }, [language]);
    
     useEffect(() => {
        if (appState === 'chatbot') {
            chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }
    }, [messages, isLoading, appState]);

    const sendMessage = async (message: string) => {
        if (!chatSession) {
            setError("Chat session is not initialized.");
            return;
        }

        setIsLoading(true);
        setError(null);
        
        setMessages(prev => [...prev, {role: 'model', content: ''}]);

        try {
            const stream = await chatSession.sendMessageStream({ message });
            let text = '';
            for await (const chunk of stream) {
                text += chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1].content = marked.parse(text);
                    return newMessages;
                });
            }
        } catch (err) {
            console.error("Error sending message:", err);
            setError(content[language].sendError);
            setMessages(prev => prev.slice(0, prev.length-1));
        } finally {
            setIsLoading(false);
            setActiveTopic(null);
        }
    };

    const handleTopicClick = async (topic: {id: string, name: string}) => {
        if (isLoading) return;
        setActiveTopic(topic.id);
        const prompt = `Tell me about ${topic.name}`;
        setMessages(prev => [...prev, { role: 'user', content: prompt}]);
        await sendMessage(prompt);
    };

    const handleFormSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (isLoading || !userInput.trim()) return;
        
        const textToSend = userInput.trim();
        setUserInput('');
        setMessages(prev => [...prev, { role: 'user', content: textToSend}]);
        await sendMessage(textToSend);
    }
    
    const generateStars = (count: number) => {
        return Array.from({ length: count }).map((_, i) => (
            <div
                key={i}
                className="star"
                style={{
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                    width: `${Math.random() * 2 + 1}px`,
                    height: `${Math.random() * 2 + 1}px`,
                    animationDelay: `${Math.random() * 5}s`,
                }}
            />
        ));
    };
    
    const toggleLanguage = () => setLanguage(prev => prev === 'kn' ? 'en' : 'kn');

    const renderLandingPage = () => (
        <div className="landing-page">
            <div className="background-details">
                <div className="glowing-map-container"><KarnatakaMap /></div>
            </div>

            <h1 className="landing-title">{content[language].landingTitle}</h1>

            <div className="character-and-button">
                <ChatbotCharacter />
                <button className="enter-button" onClick={() => setAppState('chatbot')}>
                    {content[language].enterButton}
                </button>
            </div>
            
            <div className="landing-topics">
                {content[language].landingTopics.map(topic => (
                    <div key={topic} className="landing-topic-button">{topic}</div>
                ))}
            </div>
        </div>
    );
    
    const renderChatbotPage = () => (
      <div className="chatbot-page">
          <header>
              <div className="karnataka-map-container">
                <KarnatakaMap />
              </div>
              <h1 className="main-title">{content[language].mainTitle}</h1>
          </header>

          <main>
              <div className="topics-container">
                  {content[language].chatTopics.map((topic) => (
                      <button
                          key={topic.id}
                          className={`topic-button ${activeTopic === topic.id ? 'active' : ''}`}
                          onClick={() => handleTopicClick(topic)}
                          disabled={isLoading}
                      >
                          <span className="icon">{TopicIcons[topic.icon]}</span>
                          {topic.name}
                      </button>
                  ))}
              </div>

              <div className="hologram-container">
                  <div className="chatbot-avatar">
                      <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                          <g fill="var(--hologram-blue)">
                              <circle cx="50" cy="50" r="45" fill="rgba(2,0,36,0.8)"/>
                              <path d="M50,5 A45,45 0 0,1 50,95 A45,45 0 0,1 50,5 M50,10 A40,40 0 0,0 50,90 A40,40 0 0,0 50,10" fill="var(--hologram-blue)"/>
                              <circle cx="50" cy="50" r="30" fill="var(--space-dark)"/>
                              <circle cx="50" cy="50" r="15" fill="var(--hologram-blue)"/>
                              <circle className="pulsing-inner-orb" cx="50" cy="50" r="10" fill="var(--text-light)"/>
                          </g>
                      </svg>
                  </div>
                  <div className="hologram-screen" aria-live="polite">
                     {messages.map((msg, index) => (
                       <div
                          key={index}
                          className={`chat-content ${msg.role}-message`}
                          dangerouslySetInnerHTML={{ __html: msg.content }}
                       />
                     ))}
                     {isLoading && (
                         <div className="chat-content model-message">
                             <div className="pulsing-orb"></div>
                         </div>
                     )}
                     {error && <p className="error-message">{error}</p>}
                     <div ref={chatEndRef} />
                  </div>
              </div>
              
               <form className="chat-input-container" onSubmit={handleFormSubmit}>
                  <input
                      type="text"
                      className="chat-input"
                      placeholder={content[language].inputPlaceholder}
                      value={userInput}
                      onChange={(e) => setUserInput(e.target.value)}
                      disabled={isLoading}
                      aria-label="Chat input"
                  />
                  <button type="submit" className="send-button" disabled={isLoading || !userInput.trim()}>
                      {content[language].sendButton}
                  </button>
              </form>
          </main>
      </div>
    );

    return (
        <div className="app-container">
            <KarnatakaFlag />
            <button onClick={toggleLanguage} className="language-switcher">
                {language === 'kn' ? 'EN' : 'ಕ'}
            </button>
            <div className="stars">
                {generateStars(100)}
                <div className="shooting-star"></div>
                <div className="planet p1"></div>
                <div className="planet p2"></div>
                <div className="planet p3"></div>
            </div>
            {appState === 'landing' ? renderLandingPage() : renderChatbotPage()}
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);